package Assignment5_3;

public class TemporaryEmp extends Employee{

	public TemporaryEmp(int empId, String empName, int total_leaves) {
		super(empId, empName, total_leaves);
	}

	double basic, hra, pfa;
	int balance_leaves = 30;

	int paid_leave = (total_leaves*50)/100; /*50% of total allowed leaves */
	int sick_leave = (total_leaves*25)/100; /*25% of total allowed leaves */
	int casual_leave = (total_leaves*25)/100;  /*25% of total allowed leaves */
	int pl_balance = paid_leave;
	int sl_balance = sick_leave;
	int cl_balance = casual_leave;

	@Override
	void calculate_balance_leaves() {

		balance_leaves = pl_balance + sl_balance + cl_balance;

		System.out.println("Paid leave balance : " + pl_balance);
		System.out.println("Sick leave balance : " + sl_balance);
		System.out.println("Casual leave balance : " +cl_balance);

		System.out.println(empName + ": You have Total " + balance_leaves + " Leaves left!");	
		System.out.println();
		System.out.println("*(Leaves converted into integers)");
	}

	@Override
	boolean avail_leave(int no_of_leaves, char type_of_leave) {

		boolean approved = false;

		if (type_of_leave == 'P') {   /*Paid leave requested by employee */
			if (no_of_leaves > pl_balance) {  /*Check if the requested number of leaves available for employee */
				approved = false;
			}else{
				pl_balance = pl_balance - no_of_leaves; /*If available, approve the leave and subtract it from total balance leaves */
				approved = true;
			}
		}

		if (type_of_leave == 'S') {   /*Sick leave requested by employee */
			if (no_of_leaves > sl_balance) {
				approved = false;
			}else{
				sl_balance = sl_balance - no_of_leaves;
				approved = true;
			}
		}

		if (type_of_leave == 'C') {   /*Casual leave requested by employee */
			if (no_of_leaves > cl_balance) {
				approved = false;
			}else{
				cl_balance = cl_balance - no_of_leaves;
				approved = true;
			}
		}

		return approved;


	}

	@Override
	void calculate_salary() {

		basic = 20000;
		hra = (basic*50)/100;
		pfa = (basic*12)/100;

		total_salary = (basic + hra) - pfa;

		System.out.println("Basic Pay = " + basic + "rs");
		System.out.println("HRA = " + hra + "rs");
		System.out.println("PF = " + pfa + "rs");
		System.out.println(empName + " : Your total salary = " + total_salary + "rs");
	}

}
