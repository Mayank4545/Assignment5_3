package Assignment5_3;

public abstract class Employee {

	int empId;
	String empName;
	int total_leaves;
	double total_salary;
	
	public Employee(int empId, String empName, int total_leaves) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.total_leaves = total_leaves;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getTotal_leaves() {
		return total_leaves;
	}
	public void setTotal_leaves(int total_leaves) {
		this.total_leaves = total_leaves;
	}
	abstract void calculate_balance_leaves();
	abstract boolean avail_leave(int no_of_leaves, char type_of_leave);
	abstract void calculate_salary();
	
}
