package Assignment5_3;

import java.util.Scanner;

public class Assignment5_3{

	public static void main(String[] args) {

		int empId;
		String empName;
		int empType;
		boolean approved;
		int exit;

		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("********************************");
		System.out.println("Give Employee Details:");
		System.out.println("Employment type?");
		System.out.println("1. Permanent  2. Temporary");
		empType = s.nextInt();
		System.out.println("Employee ID :");
		empId = s.nextInt();
		System.out.println("Employee Name : ");
		empName = s.next();

		if (empType == 1) {
			PermanentEmp emp = new PermanentEmp(empId, empName, 30);

			do{
				System.out.println("********************************");

				System.out.println("Which operation you want to perform? ");
				System.out.println("1. Calculate Balance leaves.");
				System.out.println("2. Avail leave.");
				System.out.println("3. Calculate Salary.");
				if (empType == 1) {
					System.out.println("4. Print Leave Details.");	
				}
				
				System.out.println("********************************");
				int option = s.nextInt();
				
				switch (option) {
				case 1:
					emp.calculate_balance_leaves();
					break;

				case 2:
					System.out.println("Number of leaves to be availed ?");
					int no_of_leaves = s.nextInt();
					System.out.println("Type of leave?");
					System.out.println("P = Paid leave S = Sick leave C = Casual leave");
					char type_of_leave = s.next().charAt(0);
					approved = emp.avail_leave(no_of_leaves, type_of_leave);
					if (approved == true) {
						System.out.println("Congrats " + empName + " Your leave has been approved for " +no_of_leaves + " days!!");
					}else{
						System.out.println("Sorry " + empName + " You are running out of leaves. Leave not approved.");
					}
					break;

				case 3:
					emp.calculate_salary();
					break;

				case 4:
					emp.print_leave_details();
					break;

				default:
					break;
				}

				System.out.println("Do you want to continue?");
				System.out.println("1. Yes 2. No" );
				exit = s.nextInt();
			}while(exit != 2);
			System.out.println("Thank you " + empName + ":)");
		}else if(empType == 2){
			
			TemporaryEmp emp = new TemporaryEmp(empId, empName,10);
			do{
				System.out.println("********************************");

				System.out.println("Which operation you want to perform? ");
				System.out.println("1. Calculate Balance leaves.");
				System.out.println("2. Avail leave.");
				System.out.println("3. Calculate Salary.");
				if (empType == 1) {
					System.out.println("4. Print Leave Details.");	
				}
				
				System.out.println("********************************");
				int option = s.nextInt();
				
				switch (option) {
				case 1:
					emp.calculate_balance_leaves();
					break;

				case 2:
					System.out.println("Number of leaves to be availed ?");
					int no_of_leaves = s.nextInt();
					System.out.println("Type of leave?");
					System.out.println("P = Paid leave S = Sick leave C = Casual leave");
					char type_of_leave = s.next().charAt(0);
					approved = emp.avail_leave(no_of_leaves, type_of_leave);
					if (approved == true) {
						System.out.println("Congrats " + empName + " Your leave has been approved for " +no_of_leaves + " days!!");
					}else{
						System.out.println("Sorry " + empName + " You are running out of leaves. Leave not approved.");
					}
					break;

				case 3:
					emp.calculate_salary();
					break;

				default:
					break;
				}

				System.out.println("Do you want to continue?");
				System.out.println("1. Yes 2. No" );
				exit = s.nextInt();
			}while(exit != 2);
			System.out.println("Thank you " + empName + ":)");
		}
	}
}
